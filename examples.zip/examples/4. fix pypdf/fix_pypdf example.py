from pypdfplot import fix_pypdf

fix_pypdf('linearized.pdf',in_place = False)
